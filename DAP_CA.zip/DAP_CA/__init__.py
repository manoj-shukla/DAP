import asyncio
from methods.airPollutionStates import dataset_one
from methods.airPollutionByIndustry import dataset_two
from methods.airPollutionIndustrialEmission import dataset_three
from methods.airQualityMiniplace import dataset_four


async def main():
    
    state_air_pollution = loop.create_task(dataset_one())
    city_air_pollution = loop.create_task(dataset_four())
    industry_toxic_pollution = loop.create_task(dataset_three())
    industry_greenhouse_toxic_pollution = loop.create_task(dataset_two())
    
    await asyncio.wait([state_air_pollution, city_air_pollution, industry_toxic_pollution, industry_greenhouse_toxic_pollution])
   
    

if __name__ == "__main__":
    try:
        loop = asyncio.get_event_loop()
        loop.run_until_complete(main())
    except Exception as e:
        print("Something went wrong!", e)
      
  