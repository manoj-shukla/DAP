
# -*- coding: utf-8 -*-
import requests
import time
import io
from yaspin import yaspin
import pandas as pd
import json, csv
class Services:
    
    def __init__(self):
        """ Intitilaization of Process Services"""       
        
    
    def loadData(self, url): 
        """ This method get data from API. It accepts {url} and return json data."""
        headers = {
            'Cache-Control': "no-cache",
            'Host': "s3.amazonaws.com",
            'Accept-Encoding': "gzip, deflate",
            'Connection': "keep-alive",
            'cache-control': "no-cache"
        }

        try:
            return requests.request("GET", url, headers=headers)
        except:
            pass
    
    
    def csvToJson(self, data):
        """This method convert {csv_data} and return json data"""
        return pd.read_csv(io.StringIO(data.decode('ISO-8859-1')))
    
    
    def updateCSV(self, file, data):
        """ This method accept json data can write into inputed file. """
        for row in data.iterrows():
            row[1].to_json(file, orient='index')
            file.write("\n")
            
            
    def jsontocsv(self, jsonobj, file):
        """ This method accepts {json_object} and write in to give {file}"""
        dicts = jsonobj
        out = open(file, 'w')
        writer = csv.DictWriter(out, dicts[0].keys())
        writer.writeheader()
        writer.writerows(dicts)
        
    def loadCSV(self, path, name):
        """ This method read csv data without any lib accept {Path} and {Name}"""
        data = []
        with open(path+name+'.csv') as csvFile:
            csvReader = csv.DictReader(csvFile)
            for csvRow in csvReader:
                data.append(csvRow)
        return data
    
    def loadJSON2(self, path, file):
        """ This method read json file and return json content. It accepts {path} and {file}"""
        with open(path+file+'.json') as template:
            return  json.load(template)
        
       
    
    def readJSONFile(self, file_path): 
        """ This method read json file and return json content. It accepts {file_path}"""
        with open(file_path) as f:
            data = json.load(f)        
        return data
       
    def updateJSONFile(self, path, name, data):
        """ This method read json content. It accepts {json_data} and {Path} and {Name} and write the content in it."""
        with open(path+name+'.json', 'w') as jsonFile:
            jsonFile.write(json.dumps(data, indent=4))
        
    def black(text):
        print('\033[32m', text, '\033[0m', sep='')
        
        
    def loading(self, process):
        with yaspin(text="", color="yellow") as spinner:
            time.sleep(4)  # time consuming code    
            spinner.ok(process+ " is Done. ✅ ")
            
    def getHeaders(self, path, name):
        return list(pd.read_csv(path+name+'.csv',sep="|",nrows=1).columns)
    
    def pgToCSV(self, headers, path, file, records):
        with open(path+file+'.csv', 'w') as f:
            writer = csv.writer(f, delimiter=',')
            writer.writerow(headers)
            for row in records:
                writer.writerow(row)