# -*- coding: utf-8 -*-

import pymongo



class MONGO_CONNECT:
    """Mongo DB connection and methods to perform curd operation """
    def __init__(self, dbname):
        """databse connection use {database} name"""
        self.dbname = dbname

    def connect_mongo(self):
        """connect to database """
        client = pymongo.MongoClient("mongodb://localhost:27017/")  
        return client[self.dbname]

    def create_collection(self, name):
        """Creating new collection by providing {name}"""
        connect = self.connect_mongo()
        collection = connect[name]
        #data.close()
        return collection

    def insert_many(self, col, data):
        """Insert rows into {collection} and {data}"""
        #cl = pymongo.MongoClient()
        db = self.connect_mongo()#cl[self.dbname]
        col = db[col]
        return col.insert_many(data, ordered=True, bypass_document_validation=False, session=None)
    
    def insert(self, col, data):
        db = self.connect_mongo()#cl[self.dbname]
        col = db[col]
        for index in range(len(data)):
            col.insert(data[index], check_keys=False)
        

    def getData(self, name):
        db = self.connect_mongo()#cl[self.dbname]
        collection = db[name]
        return collection.find({},  {'_id': False})


