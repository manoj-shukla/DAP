# -*- coding: utf-8 -*-

from psycopg2 import connect
from psycopg2 import sql
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
import configparser
details = configparser.ConfigParser()
details.read('config.ini')

class PGSQL_CONNECT:
    """Postgres DB connection and methods to perform curd operation """
    
    def __init__(self):
        """databse connection use {database} name""" 
        self.config =  {
            "user":  details.get('postgresql', 'user'),
            "host":  details.get('postgresql', 'host'),
            "database":  details.get('postgresql', 'database'),
            "password":  details.get('postgresql', 'password'),
            "port":  details.get('postgresql', 'port'),
        } 
        
        
       

    def connect_pgsql(self):
        """connect to database """        
        try:           
            conn = connect(host=self.config["host"], database=self.config["database"], user=self.config["user"], password=self.config["password"])
            return conn
        except:
            print ("I am unable to connect to the database")
        
       
    def Create_Table(self, table_name, columns):
        """ This method creates tables IF NOT EXISTS  and accept two parameter{table_name} and {columns}."""
        conn = self.connect_pgsql()
        cur  = conn.cursor()
        try:
            CUSTOM_TABLE = f'''CREATE TABLE IF NOT EXISTS {table_name} {columns}); '''
            cur.execute(CUSTOM_TABLE)
        except:
            print("Table not created. Issue Occured!!")
        conn.commit()
        conn.close()
        cur.close()
        
    def getData(self, table_name):
        """ This method return all the rows available. In given dataset {table_name}"""
        conn = self.connect_pgsql()
        cur  = conn.cursor()
        try:
            QUERY = f'''SELECT * from {table_name};'''
            cur.execute(QUERY)
            return cur.fetchall()
        except:
            print("Error Occured while Getting data!")
        conn.commit()
        conn.close()
        cur.close()
    
    def insert_in_table(self, table_name, data):
        """This method will update given {table} with given {datset}"""  
        #try:
        conn = self.connect_pgsql()
        cur  = conn.cursor()
        for index, item in data.iterrows():
            postgres_insert_query = f""" INSERT INTO {table_name} (id, State, Date_Local, NO2_AQI, O3_AQI, SO2_AQI) VALUES (%s, %s, %s, %s, %s, %s)"""
            record_to_insert = (index, item['State'], item['Date Local'], item['NO2 AQI'], item['O3 AQI'], item['SO2 AQI'])
            try:
                if(item['State'] and item['Date Local'] and item['NO2 AQI'] and item['SO2 AQI']):
                    cur.execute(postgres_insert_query, tuple(record_to_insert))                
            except:
               pass
            
        conn.commit()
        conn.close()
        cur.close()
        
    def insert_in_table2(self, table_name, data):
        """Insert rows into {collection} and {data}"""  
        conn = self.connect_pgsql()
        cur  = conn.cursor()
        for index, item in data.iterrows():
#           
            postgres_insert_query = f"""INSERT INTO {table_name} (id, year, st, chemical, unit_of_measure, fugitive_air, stack_air, underground, on_site_release_total, potw_trns_trt, total_releases) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
            record_to_insert = (index, item['1. YEAR'], item['8. ST'], item['30. CHEMICAL'], item['39. UNIT OF MEASURE'], item['40. 5.1 - FUGITIVE AIR'],
                                item['41. 5.2 - STACK AIR'], item['43. 5.4 - UNDERGROUND'], item['54. ON-SITE RELEASE TOTAL'],
                                item['56. 6.1 - POTW - TRNS TRT'], item['96. TOTAL RELEASES'])           
            try:
                cur.execute(postgres_insert_query, tuple(record_to_insert))                
            except:
               pass
           
        conn.commit()
        conn.close()
        cur.close()
        
        
    def insert_in_table3(self, table_name, data):
        """Insert rows into {collection} and {data}"""  
       
        conn = self.connect_pgsql()
        cur  = conn.cursor()
        
        for index, item in data.iterrows():
            postgres_insert_query = f"""INSERT INTO {table_name} (id, x, y, objectid, date, sample_id, parameter, results, units, cas, hrv, description, address, city_1, state, zip) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
            record_to_insert = (index, item['X'], item['Y'], item['ObjectID'], item['Date'], item['Sample_ID'],
                                item['Parameter'], item['Results'], item['Units'],
                                item['CAS'], item['Name'], item['Description'], item['Address'], item['City_1'], item['State'], item['Zip'])           
            try:
                if(item['X'] and item['Y'] and item['ObjectID'] and item['Date'] and item['Sample_ID'] and item['Parameter'] and item['Results'] and item['Units'] and item['CAS'] and item['HRV'] and  item['Description'] and item['Address'] and item['City_1'] and item['State'] and item['Zip']):
                    cur.execute(postgres_insert_query, tuple(record_to_insert))
                
                
            except:
               pass
#            
        conn.commit()
        conn.close()
        cur.close()
        
    def insert_in_table4(self, table_name, data):
        """Insert rows into {collection} and {data}"""  
        conn = self.connect_pgsql()
        cur  = conn.cursor()
        
        for index, item in data.iterrows():
            postgres_insert_query = f"""INSERT INTO {table_name} (id, unique_id, rank_ghg_14, ghg_id, tri_air_emissions_10_in_lbs, tri_air_emissions_11_in_lbs, latitude,longitude) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"""
            record_to_insert = (index, item["Unique ID"],item["Rank_GHG_14"], item['GHG_ID'], item['TRI_Air_Emissions_11_in_lbs'], item['TRI_Air_Emissions_10_in_lbs'], item["Latitude"], item["Longitude"] )             
            try:
                cur.execute(postgres_insert_query, tuple(record_to_insert))
            except:
               pass
#            
        conn.commit()
        conn.close()
        cur.close()
        
    def isAvailable(self, dbname):       
        #connect = f"""user={self.config['user']} password={self.config['password']}"""
        conn = connect("host=localhost user=postgres password=postgres")
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cur  = conn.cursor()        
        #print("connect", cur)
        Query =f""" select exists(SELECT datname FROM pg_catalog.pg_database WHERE lower(datname) = lower('{dbname}'));"""
        return cur.execute(sql.SQL("CREATE DATABASE IF NOT EXISTS {}").format(sql.Identifier(dbname)))
