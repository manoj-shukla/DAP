  #### DATABASE ANALYSIS AND PROGRAMMING 

### Database ~Config details

            Mongo Default:
                - UserName :- no user
                - Password :- no password
                -       URL:- mongodb://localhost:27017/
            Postgres Default:
                - UserName :- postgres
                - Password :- postgres
                -       URL:- localhost
                
                After project will successfull get executed new databse and table will becreated belwo are the details.
                
                Mongo:-
                    Database:- DAP
                    CollectionNames:- [state_air_pollution_data, City_air_pollution_data, Industry_air_pollution_data, Greenhouse_air_pollution_data]
                Postgres:- 
                    Database:- dap_ca_manoj
                    Tablename:- [state_air_pollution_data, City_air_pollution_data, Industry_air_pollution_data, Greenhouse_air_pollution_data]
                



### IDE
        Spider is the IDE used to develop this project. so, best to use in Anaconda Spider
        
### Programming Langage
        We have used python 3.6 to develop this project.
        
##### Project overview ########


###init.py:- 
        init file is the mail file whihc we need to execute in order to get the results.
        async lib is getting used to execute different methods. we have four methods here whihc perform 
        end to end process described below.
        
### Process:- 
        **We are retreving data from different source.[Kaggle, data.gov]
            Step1:- store data in mongo using(pymongo lib) because of unstructred nature of data.
            Step2:- Retrevive data from mongo. clean using python lib (e.g:- numpy)
            Step3:- Save Data in to Postgres using (psymg2 lib)
            Step4:- Get Data from Postgres and plot related graph using matplotlib, folio, and others..
    
### Controller:- 
        Controller is a file whihc contain all the methods whihc we need to perform more than once in order to retreive and modify data.

### Model:- 
        **There are tow file available one for Mongo DB operations and another one for Postgres SQL operation
            
            *MONGO:- Mongo modal class has all the methods available whihc make the connection with mongo, create collections and retrevice and update detialsi in mongo collections
            
            *POSTGRES_SQL:- Postgres Modal class has all the methods available whihc make the connection with Postgres DB, and perform all the curd operation as per need.
### Methods:- 
    **There are Four methods available in this project. whihc perform data retreving manupulation storing in mongo and postgres and ploting graph.
        
        *Method 1. (airPollutionStates.py):- This method perform retreving data, cleaning storing in mongo and postgres and ploting grapth on mentoined dataset.
        *Method 2. (airQualityMiniplace.py) :- This method perform retreving data, cleaning storing in mongo and postgres and ploting grapth on mentoined dataset.
        *Method 3. (airPollutionIndustrialEmission.py):- This method perform retreving data, cleaning storing in mongo and postgres and ploting grapth on mentoined dataset.
        *Method 4. (airPollutionByIndustry.py):- This method perform retreving data, cleaning storing in mongo and postgres and ploting grapth on mentoined dataset.
    

