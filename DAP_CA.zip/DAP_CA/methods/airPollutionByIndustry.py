# -*- coding: utf-8 -*-

from Models.mongomodel import MONGO_CONNECT
from Models.pgsqmodel import PGSQL_CONNECT
from Controllers.process import Services
import pandas as pd
import matplotlib.pyplot as plt
plt.style.use('fivethirtyeight')
import folium
import folium.plugins
import warnings
warnings.filterwarnings('ignore')
from folium.plugins import HeatMap
import matplotlib.pyplot as plt
import matplotlib.pyplot as plt 
import matplotlib.image as img    

async def dataset_two():
    service = Services()
    mongo = MONGO_CONNECT("pollution")
    pgsql = PGSQL_CONNECT()
    
    """ This function initiate dataset Air pollution in USA"""
    csv_path ="./data/csv_data/"
    json_path = "./data/json_data/"
    parsedPath = "./data/parsedData/"
    mongo_path = "./data/mongo/"
    fileName = "facility_air_pollution_datset_all_acilities"
    # Getting Data from sourceM
    InputDataCSV = service.loadCSV(csv_path, fileName)
    #Convert csv to json and saving in json file in dat folder
    service.updateJSONFile(json_path, fileName, InputDataCSV)
    #read json file from dat folder
    json_data = service.readJSONFile(json_path+fileName+'.json')
    #unstrucutred dat so we have to save in Mongo DB
    mongo.insert("dataset_pol2", json_data)
    #Get data from Mongo
    mongo_data = mongo.getData('dataset_pol2')
    service.jsontocsv(mongo_data, mongo_path+fileName+'.csv')
    df = pd.read_csv(csv_path+fileName+'.csv')  
    # create table using column 
    
    columns = """(id SERIAL PRIMARY KEY, unique_id varchar(50), rank_ghg_14 varchar(50), ghg_id varchar(50), tri_air_emissions_10_in_lbs varchar(50), tri_air_emissions_11_in_lbs varchar(50), latitude varchar(50), longitude varchar(50) """
    pgsql.Create_Table('greenhouse_air_quality', columns)
    
    pgsql.insert_in_table4("greenhouse_air_quality", df)
#    
#    #get data from database
    data = pgsql.getData("greenhouse_air_quality")
    headers = ["Unique ID","Rank_GHG_14", 'GHG_ID', 'TRI_Air_Emissions_11_in_lbs', 'TRI_Air_Emissions_10_in_lbs', "Latitude", "Longitude"]
    service.pgToCSV(headers, parsedPath, fileName, data)
    df = pd.read_csv(parsedPath+fileName+'.csv') 
#    
    df['Rank_GHG_14'] = df['Rank_GHG_14'].fillna((df['Rank_GHG_14'].mean()))
    df['GHG_ID'] = df['GHG_ID'].fillna((df['GHG_ID'].mean()))
    df['TRI_Air_Emissions_11_in_lbs'] = df['TRI_Air_Emissions_11_in_lbs'].fillna((df['TRI_Air_Emissions_11_in_lbs'].mean()))
    df['TRI_Air_Emissions_10_in_lbs'] = df['TRI_Air_Emissions_10_in_lbs'].fillna((df['TRI_Air_Emissions_10_in_lbs'].mean()))
    map_Evansville = folium.Map(location=[37.974764, -87.555848], zoom_start = 13)
    df['Latitude'] = df['Latitude'].astype(float)
    df['Longitude'] = df['Longitude'].astype(float)
    df = df[['Latitude', 'Longitude']]
    df = df.dropna(axis=0, subset=['Latitude','Longitude'])
    heat_data = [[row['Latitude'],row['Longitude']] for index, row in df.iterrows()]
    HeatMap(heat_data).add_to(map_Evansville)    
    map_Evansville
    #This code will run in Spyder so, map will not render so attaching image     
    plt.axis('off')
    # reading png image file 
    im = img.imread('heatmap.png')       
    # show image 
    plt.imshow(im)
    