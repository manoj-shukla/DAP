###- Minisota dataset Effect of different Toxic data
from Models.mongomodel import MONGO_CONNECT
from Models.pgsqmodel import PGSQL_CONNECT
from Controllers.process import Services
import pandas as pd
import matplotlib.pyplot as plt
plt.style.use('fivethirtyeight')
import warnings
warnings.filterwarnings('ignore')


async def dataset_four():
    service = Services()
    mongo = MONGO_CONNECT("pollution")
    pgsql = PGSQL_CONNECT()
    
    """ This function initiate dataset Air pollution in USA"""
    csv_path ="./data/csv_data/"
    json_path = "./data/json_data/"
    mongo_path = "./data/mongo/"
    fileName = "airqualitymini"
    parsedPath = "./data/parsedData/"
    
    #read csv data    
    csv_data = service.loadCSV(csv_path, fileName)
    
    #conver csv data into json
    service.updateJSONFile(json_path, fileName, csv_data)
    
    #read json data creted above
    data = service.readJSONFile(json_path+fileName+'.json')
    
    #save json data to Mongo
    mongo.insert("dataset_pol4", data)    
    
    #get Data from Mongo
    air_data = mongo.getData('dataset_pol4')
    
    #Mongo Data to csv
    service.jsontocsv(air_data, mongo_path+fileName+'.csv')
    
    #clean csv data
    dataframe = pd.read_csv(csv_path+fileName+'.csv')
    newdata=dataframe.drop(['Name','Units1','HRV_Types'],axis=1)
    newdata.isnull().sum() 
    
    # create table using column 
    columns = """(id SERIAL PRIMARY KEY, X VARCHAR(50), Y VARCHAR(50), ObjectID VARCHAR(50), Date VARCHAR(50),
        Sample_ID VARCHAR(50),Parameter VARCHAR(50), Results VARCHAR(50), Units VARCHAR(50), CAS VARCHAR(50),
        HRV VARCHAR(50), Description VARCHAR(50), 
        Address VARCHAR(50), City_1 VARCHAR(50), State VARCHAR(50), Zip VARCHAR(50) """
    pgsql.Create_Table('minipolis_air_quality', columns)
    pgsql.insert_in_table3("minipolis_air_quality", dataframe)
    
    #get data from database
    data = pgsql.getData("air_pollution")
    headers = ['X', 'Y', 'ObjectID', 'Date', 'Sample_ID', 'Parameter', 'Results',
       'Units', 'CAS', 'HRV', 'Description',
       'Address', 'City_1', 'State', 'Zip']
    service.pgToCSV(headers, parsedPath, fileName, data)
    
    #plot graph
    dataframe = pd.read_csv(parsedPath+fileName+'.csv')
    dataframe.isnull().sum()
    
    
    plt.figure(figsize=(10,6))
    dataframe.Parameter.value_counts()[:6].plot(kind="bar")
    plt.xticks(rotation=10)
    plt.ylabel("Result")
    plt.xlabel("Chemical parameters")
    plt.title("Results of Parameters")
    
   