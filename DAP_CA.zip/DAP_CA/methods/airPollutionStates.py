######- Air Pollution dataset to show Effect of Different Toxic gases over different states of USA.

#Globals Imports
from Models.mongomodel import MONGO_CONNECT
from Models.pgsqmodel import PGSQL_CONNECT
from Controllers.process import Services
import pandas as pd
import matplotlib.pyplot as plt
import json

async def dataset_one():
    service = Services()
    mongo = MONGO_CONNECT("pollution")
    pgsql = PGSQL_CONNECT()
    
    """ This function initiate dataset Air pollution in USA"""
    URL = "https://s3.amazonaws.com/us.states-pollution-2000to-2015/pollution_us_2000_2016.json"
    json_path = "./data/json_data/"
    mongo_path = "./data/mongo/"
    fileName = "pollution_us_2000_2016"
    parsedPath = "./data/parsedData/"
   
    # Getting Data from source
    data = json.loads(service.loadData(URL).text)
    #if data is moved from url  we will use local data
    if(len(data["results"]) == 0):
        data = service.readJSONFile(json_path+fileName+'.json')   
    #unstrucutred dat so we have to save in Mongo DB
    mongo.insert("dataset_pol1", data['results'])
    #Get data from Mongo
    air_data = mongo.getData('dataset_pol1')
    
    #convert in CSV
    service.jsontocsv(air_data, mongo_path+fileName+'.csv')
    
    #Clean Data 
    parsedData = pd.read_csv(mongo_path+fileName+'.csv')
    parsedData = parsedData.drop(['County Code','Site Num','Address','NO2 Units','O3 Units','SO2 Units','CO Units'],axis=1)
    
    #Postgres    
    pgsql = PGSQL_CONNECT()   
    columns = """(id SERIAL PRIMARY KEY, State VARCHAR(50), Date_Local VARCHAR(50), NO2_AQI VARCHAR(50), O3_AQI VARCHAR(50), SO2_AQI VARCHAR(50)"""
   
    #Create Tables    
    pgsql.Create_Table('air_pollution', columns)
    
    #Insert Data in postgres table
    pgsql.insert_in_table("air_pollution", pd.DataFrame(data['results']))
    
    #get data from postgres in csv format
    pgData = pgsql.getData("air_pollution")
    headers = ["id", "State", "Date Local","NO2 AQI","O3 AQI", "SO2 AQI"]
    service.pgToCSV(headers, parsedPath, fileName, pgData)
    
    #Parsed data retrevied from postgres. Plotting graph on that
    poll = pd.read_csv(parsedPath+fileName+'.csv')
    pollSt = poll[['State','Date Local','NO2 AQI','O3 AQI','SO2 AQI']]
    pollSt = pollSt.dropna(axis='rows')  # Delete rows with NAs
    pollSt = pollSt[pollSt.State!='Country Of Mexico']  # Delete Mexico
    pollSt['Date Local'] = pd.to_datetime(pollSt['Date Local'],format='%Y-%m-%d')  # Change date from string to date value
    pollSt = pollSt.groupby(['State','Date Local']).mean()  # Take mean values if there are depulicated entries
    pollStGrouped = pollSt.groupby(level=0)
    
    ## Ploting 4 AQIs with top 4 states
    plt.figure(figsize=(12,8))
    
    # NO2 AQI
    plt.subplot(221)
    pollNO2 = pollStGrouped['NO2 AQI']
    pollNO2Top = pollNO2.mean().nlargest(4).index
    for i in range(len(pollNO2Top)):
        pollNO2.get_group(pollNO2Top[i]).groupby(pd.Grouper(level='Date Local',freq='M')).mean().plot()
    plt.legend(pollNO2Top,loc=3,fontsize='small')
    plt.title('NO2 AQI')
    
    # O3 AQI
    plt.subplot(222)
    pollO3 = pollStGrouped['O3 AQI']
    pollO3Top = pollO3.mean().nlargest(4).index
    for i in range(len(pollO3Top)):
        pollO3.get_group(pollO3Top[i]).groupby(pd.Grouper(level='Date Local',freq='M')).mean().plot()
    plt.legend(pollO3Top,loc=3,fontsize='small')
    plt.title('O3 AQI')
    
    # SO2 AQI
    plt.subplot(223)
    pollSO2 = pollStGrouped['SO2 AQI']
    pollSO2Top = pollSO2.mean().nlargest(4).index
    for i in range(len(pollSO2Top)):
        pollSO2.get_group(pollSO2Top[i]).groupby(pd.Grouper(level='Date Local',freq='M')).mean().plot()
    plt.legend(pollSO2Top,loc=3,fontsize='small')
    plt.title('SO2 AQI')
    
    #Plot   
    plt.tight_layout()
    plt.show()
    
    
    
    
    
    