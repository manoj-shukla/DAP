#Dataset is for Air Pollution Bases on Industry
from Models.mongomodel import MONGO_CONNECT
from Models.pgsqmodel import PGSQL_CONNECT
from Controllers.process import Services
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
plt.style.use('fivethirtyeight')
import warnings
warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt

async def dataset_three():
    service = Services()
    mongo = MONGO_CONNECT("pollution")
    pgsql = PGSQL_CONNECT()    
    csv_path ="./data/csv_data/"
    json_path = "./data/json_data/"
    mongo_path = "./data/mongo/"
    fileName = "tri_2015_us"
    parsedPath = "./data/parsedData/"
    
    # Getting Data from source
    csv_data = service.loadCSV(csv_path, fileName)    
    
    #Conver csv to json and saving in json file in dat folder
    service.updateJSONFile(json_path, fileName, csv_data)
    
    #read json file from dat folder
    data = service.readJSONFile(json_path+fileName+'.json')
    
    #unstrucutred dat so we have to save in Mongo DB
    mongo.insert("dataset_pol3", data)
    
    #Get data from Mongo
    air_data = mongo.getData('dataset_pol3')  
    
    #convert in CSV
    service.jsontocsv(air_data, mongo_path+fileName+'.csv')
    
    #convert in CSV
    df = pd.read_csv(mongo_path+fileName+'.csv')
    
    df = df.drop("3. FRS ID", axis=1)
    df = df.drop("4. FACILITY NAME", axis=1)
    df = df.drop("5. STREET ADDRESS", axis=1)
    df = df.drop("6. CITY", axis=1)
    df = df.drop(["9. ZIP", "7. COUNTY","10. BIA", "11. TRIBE"], axis=1)
    df = df.drop(["12. LATITUDE", "13. LONGITUDE", "14. FEDERAL FACILITY", "15. INDUSTRY SECTOR CODE", "16. INDUSTRY SECTOR"], axis=1)
    df = df.drop(["17. PRIMARY SIC", "18. SIC 2", "19. SIC 3", "20. SIC 4", "21. SIC 5", "22. SIC 6", "23. PRIMARY NAICS", "24. NAICS 2", "25. NAICS 3", "26. NAICS 4", "27. NAICS 5", "28. NAICS 6"], axis=1)
    df = df.drop(["29. DOC_CTRL_NUM", "31. CAS #/COMPOUND ID", "32. SRS ID", "33. CLEAN AIR ACT CHEMICAL", "34. CLASSIFICATION", "35. METAL", "36. METAL CATEGORY", "37. CARCINOGEN", "38. FORM TYPE"], axis=1)
    df = df.drop(["42. 5.3 - WATER", "44. 5.4.1 - UNDERGROUND CL I", "45. 5.4.2 - UNDERGROUND C II-V", "46. 5.5.1 - LANDFILLS", "47. 5.5.1A - RCRA C LANDFILL", "48. 5.5.1B - OTHER LANDFILLS", "49. 5.5.2 - LAND TREATMENT", "50. 5.5.3 - SURFACE IMPNDMNT", "51. 5.5.3A - RCRA SURFACE IM", "52. 5.5.3B - OTHER SURFACE I", "53. 5.5.4 - OTHER DISPOSAL", "55. 6.1 - POTW - TRNS RLSE"], axis=1)
    df = df.drop(["57. POTW - TOTAL TRANSFERS", "58. 6.2 - M10", "59. 6.2 - M41", "60. 6.2 - M62", "61. 6.2 - M40 METAL", "62. 6.2 - M61 METAL", "63. 6.2 - M71", "64. 6.2 - M81", "65. 6.2 - M82", "66. 6.2 - M72", "67. 6.2 - M63", "68. 6.2 - M66", "69. 6.2 - M67", "70. 6.2 - M64", "71. 6.2 - M65", "72. 6.2 - M73", "73. 6.2 - M79", "74. 6.2 - M90", "75. 6.2 - M94", "76. 6.2 - M99"], axis=1)
    df = df.drop(["77. OFF-SITE RELEASE TOTAL", "78. 6.2 - M20", "79. 6.2 - M24", "80. 6.2 - M26", "81. 6.2 - M28", "82. 6.2 - M93", "83. OFF-SITE RECYCLED TOTAL", "84. 6.2 - M56", "85. 6.2 - M92", "86. OFF-SITE ENERGY RECOVERY T", "87. 6.2 - M40 NON-METAL", "88. 6.2 - M50", "89. 6.2 - M54", "90. 6.2 - M61 NON-METAL", "91. 6.2 - M69", "92. 6.2 - M95", "93. OFF-SITE TREATED TOTAL", "94. 6.2 - UNCLASSIFIED", "95. 6.2 - TOTAL TRANSFER",], axis=1)
    df = df.drop(["97. 8.1 - RELEASES", "98. 8.1A - ON-SITE CONTAINED", "99. 8.1B - ON-SITE OTHER ", "100. 8.1C - OFF-SITE CONTAIN", "101. 8.1D - OFF-SITE OTHER R", "102. 8.2 - ENERGY RECOVER ON", "103. 8.3 - ENERGY RECOVER OF", "104. 8.4 - RECYCLING ON SITE", "105. 8.5 - RECYCLING OFF SIT", "106. 8.6 - TREATMENT ON SITE", "107. 8.7 - TREATMENT OFF SITE", "108. PRODUCTION WSTE (8.1-8.7)", "109. 8.8 - ONE-TIME RELEASE", "110. PROD_RATIO_OR_ ACTIVITY", "111. 8.9 - PRODUCTION RATIO", "112. PARENT CO NAME", "113. PARENT CO DB NUM"], axis=1)
    df.isnull().sum()
    df_drop = df.dropna()
    
    #Postgres    
    columns = """(id SERIAL PRIMARY KEY, YEAR VARCHAR(100), ST VARCHAR(100), CHEMICAL VARCHAR(100), UNIT_OF_MEASURE VARCHAR(100), FUGITIVE_AIR VARCHAR(100), STACK_AIR VARCHAR(100),
              UNDERGROUND VARCHAR(100), ON_SITE_RELEASE_TOTAL VARCHAR(100), POTW_TRNS_TRT VARCHAR(100), TOTAL_RELEASES VARCHAR(100)"""
 
    #Create Tables    
    pgsql.Create_Table('industry_pollution', columns)
    
    #Insert Data in postgres table
    pgsql.insert_in_table2("industry_pollution", df)    
    
    #get data from postgres in csv format
    dataPsql = pgsql.getData("industry_pollution")
    headers = ['YEAR', '8. ST', '30. CHEMICAL', '39. UNIT OF MEASURE', '40. 5.1 - FUGITIVE AIR', '41. 5.2 - STACK AIR',
       '43. 5.4 - UNDERGROUND', '54. ON-SITE RELEASE TOTAL','56. 6.1 - POTW - TRNS TRT', '96. TOTAL RELEASES']
    service.pgToCSV(headers, parsedPath, fileName, dataPsql) 
    df = pd.read_csv(parsedPath+fileName+'.csv')
    
    
    DF = df[df["30. CHEMICAL"].isin(['NITRATE COMPOUNDS', 'SULFURIC ACID (1994 AND AFTER ACID AEROSOLS" ONLY)"', 'OZONE'])]
    DF.shape
    df_state = DF[DF["8. ST"].isin(['IN', 'NY', 'MO', 'CA', 'GA', 'TX', 'NC', 'AL', 'LA'])]
    plt.figure(figsize=(10,5))
    sns.barplot(x=df_state['8. ST'], y=df_state['40. 5.1 - FUGITIVE AIR'])
    #plt.xticks(rotation = 30)
    plt.xlabel('States')
    plt.ylabel('Total toxic Emission in Pounds')
    plt.title('Emission vs States')
    plt.figure(figsize=(10,5))
    sns.barplot(x=df_state['8. ST'], y=df_state['41. 5.2 - STACK AIR'])
    #plt.xticks(rotation = 30)
    plt.xlabel('States')
    plt.ylabel('Total chemical Emission in Pounds')
    plt.title('Chemical Emission vs States')
    plt.figure(figsize=(10,5))
    sns.barplot(x=df_state['8. ST'], y=df_state['96. TOTAL RELEASES'])
    #plt.xticks(rotation = 30)
    plt.xlabel('States')
    plt.ylabel('Total Emission in Pounds')
    plt.title('Total Emission vs States')
    DF_1 = df[df["30. CHEMICAL"].isin(['NITRATE COMPOUNDS'])]
    df_state1 = DF_1[DF_1["8. ST"].isin(['IN', 'NY', 'MO', 'CA', 'GA', 'TX', 'NC', 'AL', 'LA'])]
    plt.figure(figsize=(10,5))
    sns.barplot(x=df_state1['8. ST'], y=df_state1['96. TOTAL RELEASES'])
    #plt.xticks(rotation = 30)
    plt.xlabel('States')
    plt.ylabel('Total Nitrous in Pounds')
    plt.title('Nitrous Emission vs States')
    DF_2 = df[df["30. CHEMICAL"].isin(['SULFURIC ACID (1994 AND AFTER ACID AEROSOLS" ONLY)"'])]
    df_state2 = DF_2[DF_2["8. ST"].isin(['IN', 'NY', 'MO', 'CA', 'GA', 'TX', 'NC', 'AL', 'LA'])]
    plt.figure(figsize=(10,5))
    sns.barplot(x=df_state2['8. ST'], y=df_state2['96. TOTAL RELEASES'])
    #plt.xticks(rotation = 30)
    plt.xlabel('States')
    plt.ylabel('Total Sulphurous in Pounds')
    plt.title('Sulphurous Emission vs States')
    DF_3 = df[df["30. CHEMICAL"].isin(['OZONE'])]
    df_state3 = DF_3[DF_3["8. ST"].isin(['NY', 'MO', 'CA', 'GA', 'TX', 'NC', 'AL', 'LA'])]
    plt.figure(figsize=(10,5))
    sns.barplot(x=df_state3['8. ST'], y=df_state3['96. TOTAL RELEASES'])
    #plt.xticks(rotation = 30)
    plt.xlabel('States')
    plt.ylabel('Total Ozone in Pounds')
    plt.title('Ozone Emission vs States')